﻿using System;
namespace MixtureModel {
  class MixtureModelProgram {
    const int N = 8; const int K = 3; const int d = 2;

    static void Main(string[] args)
    {
      // -----------------------------------------------------------------
      Console.WriteLine("\nBegin mixture model with C# demo \n");
      double[][] X = new double[N][];  // 8x2 data
      X[0] = new double[] { 0.2, 0.7 }; X[1] = new double[] { 0.1, 0.9 };
      X[2] = new double[] { 0.2, 0.8 }; X[3] = new double[] { 0.4, 0.5 };
      X[4] = new double[] { 0.5, 0.4 }; X[5] = new double[] { 0.9, 0.3 };
      X[6] = new double[] { 0.8, 0.2 }; X[7] = new double[] { 0.7, 0.1 };

      Console.WriteLine("Data (height, width) to cluster looks like: ");
      Console.Write("[0] "); VectorShow(X[0]);
      Console.Write("[1] "); VectorShow(X[1]);
      Console.WriteLine(". . . ");
      Console.Write("[7] "); VectorShow(X[7]);

      Console.WriteLine("\nSetting K = 3, initializing w, a, u, V, Nk");
      double[][] w = MatrixCreate(N, K);  // 8x3 membership weights
      double[] a = new double[K] { 1.0 / K, 1.0 / K, 1.0 / K };
      double[][] u = MatrixCreate(K, d); // 3x2 Gaussian means
      double[][] V = MatrixCreate(K, d, 0.01); // variances
      double[] Nk = new double[K];  // 3 col sums of the w matrix

      u[0][0] = 0.2; u[0][1] = 0.7;  // typically from k-means
      u[1][0] = 0.5; u[1][1] = 0.5;
      u[2][0] = 0.8; u[2][1] = 0.2;

      // ShowDataStructures(w, Nk, a, u, S);

      Console.WriteLine("Performing 5 E-M update iterations ");
      for (int iter = 0; iter < 5; ++iter) {
        UpdateMembershipWts(w, X, u, V, a);  // E step
        UpdateNk(Nk, w);  // M steps
        UpdateMixtureWts(a, Nk);
        UpdateMeans(u, w, X, Nk);
        UpdateVariances(V, u, w, X, Nk);
      }

      Console.WriteLine("Clustering done. \n");
      ShowDataStructures(w, Nk, a, u, V);

      Console.WriteLine("End mixture model demo");
      Console.ReadLine();
    } // Main

    // -----------------------------------------------------------------

    static void ShowDataStructures(double[][] w, double[] Nk,
      double[] a, double[][] u, double[][] V)
    {
      Console.WriteLine("w (membership wts):"); MatrixShow(w, true);
      Console.WriteLine("Nk (w column sums):"); VectorShow(Nk, true);
      Console.WriteLine("a (mixture wts):"); VectorShow(a, true);
      Console.WriteLine("u (cluster means):"); MatrixShow(u, true);
      Console.WriteLine("V (cluster variances):"); MatrixShow(V, true);
    }

    static void UpdateMembershipWts(double[][] w, double[][] X,
      double[][] u, double[][] V, double[] a)
    {
      for (int i = 0; i < N; ++i) {
        double rowSum = 0.0;
        for (int k = 0; k < K; ++k) {
          double pdf = NaiveProb(X[i], u[k], V[k]);  // for wik
          w[i][k] = a[k] * pdf;
          rowSum += w[i][k];
        }
        for (int k = 0; k < K; ++k)
          w[i][k] = w[i][k] / rowSum;
      }
    }

    static void UpdateNk(double[] Nk, double[][] w)
    {
      for (int k = 0; k < K; ++k) {
        double sum = 0.0;
        for (int i = 0; i < N; ++i)
          sum += w[i][k];
        Nk[k] = sum;
      }
    }

    static void UpdateMixtureWts(double[] a, double[] Nk)
    {
      for (int k = 0; k < K; ++k)
        a[k] = Nk[k] / N;
    }

    // -----------------------------------------------------------------
    static void UpdateMeans(double[][] u, double[][] w, double[][] X,
      double[] Nk)
    {
      double[][] result = MatrixCreate(K, d);
      for (int k = 0; k < K; ++k) {
        for (int i = 0; i < N; ++i)
          for (int j = 0; j < d; ++j)
            result[k][j] += w[i][k] * X[i][j];

        for (int j = 0; j < d; ++j)
          result[k][j] = result[k][j] / Nk[k];
      }

      for (int k = 0; k < K; ++k)
        for (int j = 0; j < d; ++j)
          u[k][j] = result[k][j];
    }

    static void UpdateVariances(double[][] V, double[][] u,
      double[][] w, double[][] X, double[] Nk)
    {
      double[][] result = MatrixCreate(K, d);
      for (int k = 0; k < K; ++k) {
        for (int i = 0; i < N; ++i)
          for (int j = 0; j < d; ++j)
            result[k][j] += w[i][k] * (X[i][j] - u[k][j]) *
              (X[i][j] - u[k][j]);

        for (int j = 0; j < d; ++j)
          result[k][j] = result[k][j] / Nk[k];
      }

      for (int k = 0; k < K; ++k)
        for (int j = 0; j < d; ++j)
          V[k][j] = result[k][j];
    }

    static double ProbDenFunc(double x, double u, double v)
    {
      // univariate Gaussian
      if (v == 0.0) throw new Exception("var = 0 in ProbDenFun");
      double left = 1.0 / Math.Sqrt(2.0 * Math.PI * v);
      double pwr = -1 * ((x - u) * (x - u)) / (2 * v);
      return left * Math.Exp(pwr);
    }

    // -----------------------------------------------------------------

    static double NaiveProb(double[] x, double[] u, double[] v)
    {
      // poor man's multivariate Gaussian. simple average of univariates
      double sum = 0.0;
      for (int j = 0; j < d; ++j)
        sum += ProbDenFunc(x[j], u[j], v[j]);
      return sum / d;
    }

    static double[][] MatrixCreate(int rows, int cols, double v = 0.0)
    {
      double[][] result = new double[rows][];
      for (int i = 0; i < rows; ++i)
        result[i] = new double[cols];
      for (int i = 0; i < rows; ++i)
        for (int j = 0; j < cols; ++j)
          result[i][j] = v;
      return result;
    }

    static void MatrixShow(double[][] m, bool newline = false)
    {
      for (int i = 0; i < m.Length; ++i) {
        for (int j = 0; j < m[0].Length; ++j) {
          Console.Write(m[i][j].ToString("F4") + "  ");
        }
        Console.WriteLine("");
      }
      if (newline == true)
        Console.WriteLine("");
    }

    static void VectorShow(double[] v, bool newline = false)
    {
      for (int i = 0; i < v.Length; ++i)
        Console.Write(v[i].ToString("F4") + "  ");
      Console.WriteLine("");
      if (newline == true)
        Console.WriteLine("");
    }
  } // Program class
} // ns
