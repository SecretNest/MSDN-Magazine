Backing Field and Owned Entity Changes in EF Core 3.0

November 2019 MSDN Magazine Data Points Column

https://msdn.microsoft.com/en-us/magazine/mt149362?author=julie+lerman

This folder contains the .NET Core Console solution described in the article.

Also available at https://github.com/julielerman/DataPoints-Nov-2019-EFCore3DDD

Julie Lerman  
thedatafarm.com  
twitter @julielerman