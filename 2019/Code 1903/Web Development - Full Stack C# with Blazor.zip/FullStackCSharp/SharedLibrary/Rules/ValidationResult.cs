﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SharedLibrary
{
    public class ValidationResult
    {
        public bool IsValid { get; set; }
        public String Message { get; set; }
    }
}
