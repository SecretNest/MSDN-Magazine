using Expanse.Classes;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Console;

public class ExpanseContext : DbContext {
  public DbSet<Consortium> Consortia { get; set; }
  public DbSet<Ship> Ships { get; set; }
  public DbSet<Planet> Planets { get; set; }
  public DbSet<Character> Characters { get; set; }

  private ILoggerFactory GetLoggerFactory () {
    IServiceCollection serviceCollection = new ServiceCollection ();
    serviceCollection.AddLogging (builder =>
      builder.AddConsole ()
      .AddFilter (DbLoggerCategory.Database.Command.Name,
        LogLevel.Debug));
    return serviceCollection.BuildServiceProvider ()
      .GetService<ILoggerFactory> ();
  }

  protected override void OnConfiguring (DbContextOptionsBuilder optionsBuilder) {
    optionsBuilder.UseCosmos (
        "endpoint_string_here",
        "account_key_here",
        "ExpanseCosmosDemo").UseLoggerFactory (GetLoggerFactory ())
      .EnableSensitiveDataLogging (true);
  }
  protected override void OnModelCreating (ModelBuilder modelBuilder) {
    modelBuilder.Entity<Ship> ().ToContainer ("ExpanseShips");
    modelBuilder.Entity<Ship> ().OwnsOne (s => s.Origin);

  }
}