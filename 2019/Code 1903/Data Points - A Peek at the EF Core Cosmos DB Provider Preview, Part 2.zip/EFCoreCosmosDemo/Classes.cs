﻿using System;
using System.Collections.Generic;

namespace Expanse.Classes
{
    public class Consortium
    {
        public Consortium()
        {
            Ships=new List<Ship>();
            Stations=new List<Station>();
        }
        public Guid ConsortiumId { get; set; }
        public string Name { get; set; }
        public virtual List<Ship> Ships{get;set;}
        public virtual List<Station> Stations{get;set;}
    }
    public class Planet
    {
        public Guid PlanetId { get; set; }
        public string PlanetName { get; set; }
    }
    public class Ship
    {
        public Guid ShipId {get;set;}
        public string ShipName {get;set;}
        public int PlanetId {get;set;}
        public virtual Origin Origin{get;set;}
        public Guid ConsortiumId{get;set;}
    }
    public class Origin
    {
        public DateTime Date{get;set;}
        public String Location{get;set;}
    }
    public class Station
    {
        public Guid StationId {get;set;}
        public string StationName {get;set;}
        public int PlanetId {get;set;} 
    }
    public class Character
    {
        public Guid CharacterId { get; set; }
        public string Role {get;set;}
        public string Nae {get;set;}
        public int PlanetID {get;set;}
        public int? StationId {get;set;}
        public int? ShipId {get;set;}
    }
}
