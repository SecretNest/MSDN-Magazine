﻿using System;
using System.Linq;
using Expanse.Classes;
using Microsoft.EntityFrameworkCore;

namespace _2019_March_EF_Cosmos_Part2 {
  class Program {
    public static void Main (string[] args) {
      CreateDB ();
      // AddObject ();
      AddGraph ();
      // GetSomeDataBack();
      GetConsortiaWithShips ();
      // EagerLoadInclude ();
      // EagerLoadProjection();
      // ExplicitLoad();
      // LazyLoad();

    }

    private static void CreateDB () {
      using (var context = new ExpanseContext ()) {
        context.Database.EnsureDeleted ();
        context.Database.EnsureCreated ();
      }
    }
    private static void GetConsortiaWithShips () {
      using (var context = new ExpanseContext ()) {
        var consortia = context.Consortia.Include (c => c.Ships).FirstOrDefault ();

      }
    }

    private static void AddObject () {
      var consortium = new Consortium { ConsortiumId = Guid.NewGuid (), Name = "Martian Congressional Republic" };
      using (var context = new ExpanseContext ()) {
        context.Consortia.Add (consortium);
        context.SaveChanges ();

      }
    }

    private static void GetSomeDataBack () {
      using (var context = new ExpanseContext ()) {
        var consortia = context.Consortia.ToList ();

        var entries = context.ChangeTracker.Entries ().ToList ();
        Console.WriteLine (consortia.Count);
      }
    }

    private static void AddGraph () {
      var consortium = new Consortium { ConsortiumId = Guid.NewGuid (), Name = "United Nations Thursay" };
      var origin = new Origin { Date = DateTime.Now, Location = "Earth" };
      consortium.Ships.Add (new Ship { ShipId = Guid.NewGuid (), ShipName = "Nathan Hale 3rd", Origin = new Origin { Date = DateTime.Now, Location = "Earth" } });

      using (var context = new ExpanseContext ()) {
        context.Consortia.Add (consortium);

        context.Planets.Add (new Planet { PlanetId = Guid.NewGuid (), PlanetName = "Earth" });
        context.SaveChanges ();
      }
    }
    //other experiments
    private static void EagerLoadInclude () {
      using (var context = new ExpanseContext ()) {
        var consortia = context.Consortia.Include (c => c.Ships).ToList ();
      }
    }
    private static void EagerLoadProjection () {
      using (var context = new ExpanseContext ()) {
        var consortia = context.Consortia.Select (c => new { c, c.Ships }).ToList ();
      }
    }
    private static void ExplicitLoad () {
      using (var context = new ExpanseContext ()) {
        var consortium = context.Consortia.FirstOrDefault (c => c.Name.Contains ("United"));
        context.Entry (consortium).Collection (c => c.Ships).Load ();
      }
    }
    private static void LazyLoad () {
      using (var context = new ExpanseContext ()) {
        var consortium = context.Consortia.FirstOrDefault (c => c.Name.Contains ("United"));
        var shipCount = consortium.Ships.Count ();
      }
    }
  }

}