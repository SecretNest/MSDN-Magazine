A Peek at the EF Core Cosmos DB Provider
Preview, Part 2

March 2019 MSDN Magazine


https://msdn.microsoft.com/en-us/magazine/mt149362?author=julie+lerman



This folder contains the .NET Core project described in the article. It uses EF Core 3.0 PREVIEW

Julie Lerman

thedatafarm.com

twitter @julielerman