EF Core in a Docker Containerized App

April 2019 MSDN Magazine


https://msdn.microsoft.com/en-us/magazine/mt149362?author=julie+lerman



This folder contains the .NET Core API solution described in the article.

Julie Lerman

thedatafarm.com

twitter @julielerman