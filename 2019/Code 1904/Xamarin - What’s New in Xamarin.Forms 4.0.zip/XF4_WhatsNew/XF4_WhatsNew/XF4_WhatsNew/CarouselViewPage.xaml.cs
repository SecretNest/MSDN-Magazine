﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace XF4_WhatsNew
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CarouselViewPage : ContentPage
    {
        private ProductViewModel ViewModel { get; set; }
        public CarouselViewPage()
        {
            InitializeComponent();


            this.ViewModel = new ProductViewModel();
            this.BindingContext = this.ViewModel;
        }
    }
}