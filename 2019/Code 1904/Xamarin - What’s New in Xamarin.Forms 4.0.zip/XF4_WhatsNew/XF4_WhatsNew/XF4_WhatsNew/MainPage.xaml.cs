﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace XF4_WhatsNew
{
    public partial class MainPage : ContentPage
    {

        private ProductViewModel ViewModel { get; set; }

        public MainPage()
        {
            InitializeComponent();

            this.ViewModel = new ProductViewModel();
            this.BindingContext = this.ViewModel;
        }

        private void ProductList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedProduct = this.ProductList.SelectedItem as Product;

            var singleProduct = e.CurrentSelection.FirstOrDefault() as Product;

            var selectedItems = e.CurrentSelection.Cast<Product>();
            
            foreach(var product in selectedItems)
            {
                // Handle your object properties here...
            }
        }

    }
}
