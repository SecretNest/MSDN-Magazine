﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Runtime.CompilerServices;
using System.Collections.ObjectModel;
using Xamarin.Forms;

namespace XF4_WhatsNew
{
    public class Product : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        private int _productQuantity;
        private string _productName;
        private string _productImage;

        public int ProductQuantity
        {
            get
            {
                return _productQuantity;
            }
            set
            {
                _productQuantity = value;
                OnPropertyChanged();
            }
        }

        public string ProductName
        {
            get
            {
                return _productName;
            }
            set
            {
                _productName = value;
                OnPropertyChanged();
            }
        }

        public string ProductImage
        {
            get
            {
                return _productImage;
            }
            set
            {
                _productImage = value;
                OnPropertyChanged();
            }
        }
    }


    public class ProductViewModel: INotifyPropertyChanged
    {
        public ObservableCollection<Product> Products { get; set; }

        private Product _selectedProduct;
        public Product SelectedProduct
        {
            get
            {
                return _selectedProduct;
            }
            set
            {
                _selectedProduct = value;
                OnPropertyChanged();
            }
        }

        private Command _productSelectedCommand;

        public Command ProductSelectedCommand
        {
            get
            {
                return _productSelectedCommand;
            }
            set
            {
                _productSelectedCommand = value;
                OnPropertyChanged();
            }
        }

        public ProductViewModel()
        {
            // Sample products
            this.Products = new ObservableCollection<Product>();
            this.Products.Add(new Product { ProductQuantity = 50, ProductName = "Cheese", ProductImage = "Cheese.png" });
            this.Products.Add(new Product { ProductQuantity = 10, ProductName = "Water", ProductImage = "Water.png" });
            this.Products.Add(new Product { ProductQuantity = 6, ProductName = "Bread", ProductImage = "Bread.png" });
            this.Products.Add(new Product { ProductQuantity = 40, ProductName = "Tomatoes", ProductImage = "Tomato.png" });

            this.ProductSelectedCommand = new Command(ExecuteProductSelectedCommand, CanExecuteProductSelectedCommand);
        }

        private bool CanExecuteProductSelectedCommand(object arg)
        {
            return this.SelectedProduct != null;
        }

        private void ExecuteProductSelectedCommand(object obj)
        {
            // Handle your object here....
            var currentProduct = this.SelectedProduct;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
