﻿USE DB_Agilistas 
GO

CREATE TABLE [Categories] (
    [Id] uniqueidentifier NOT NULL,
    [Description] nvarchar(max) NULL,
    CONSTRAINT [PK_Categories] PRIMARY KEY ([Id])
);

GO

CREATE TABLE [Agilistas] (
    [Id] uniqueidentifier NOT NULL,
    [Name] nvarchar(max) NULL,
    [PrimaryFocusId] uniqueidentifier NOT NULL,
    [TwitterHandle] nvarchar(max) NULL,
    CONSTRAINT [PK_Agilistas] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_Agilistas_Categories_PrimaryFocusId] FOREIGN KEY ([PrimaryFocusId]) REFERENCES [Categories] ([Id]) ON DELETE CASCADE
);

GO

CREATE INDEX [IX_Agilistas_PrimaryFocusId] ON [Agilistas] ([PrimaryFocusId]);

GO



