using System;

public class Character {
        public string Name { get; set; }
        public string Bio { get; set; }
}