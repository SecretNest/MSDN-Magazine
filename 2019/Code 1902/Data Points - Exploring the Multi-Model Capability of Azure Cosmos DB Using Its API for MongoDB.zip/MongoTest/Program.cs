﻿using System;
using System.Linq;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;

namespace MongoTest {
    class Program {
        static IMongoDatabase db;

        static void Main (string[] args) {
            db = new MongoClient ().GetDatabase ("ExpanseDatabase");
            ApplyMappings ();
            //InsertShip ();
            //  AddShipAndDecommissionedShip ();
            //  GetShips ();
            //AddShipsViaContext ();
            GetDataViaAPI ();

        }

        private static void GetShips () {
            var coll = db.GetCollection<Ship> ("Ships");
            var ships = coll.AsQueryable ().OfType<Ship> ().ToList ();
        }

        private static void InsertShip () {
            var ship = new Ship { Name = "Donnager" };
            ship.Crew.Add (new Character { Name = "Bobbie Draper", Bio = "Fierce Marine" });
            var coll = db.GetCollection<Ship> ("Ships");
            coll.InsertOne (ship);

        }

        private static void AddShipAndDecommissionedShip () {

            var ship = new Ship { Name = "Donnager" };
            ship.Crew.Add (new Character { Name = "Bobbie Draper", Bio = "Fierce Marine" });
            var decommissionedShip = new DecommissionedShip { Name = "Canterbury", Date = new DateTime (2350, 1, 1) };
            var coll = db.GetCollection<Ship> ("Ships");
            coll.InsertMany (new [] { ship, decommissionedShip });
        }

        private static void AddShipsViaContext () {
            var ship = new Ship { Name = "Donnager" };
            ship.Crew.Add (new Character { Name = "Bobbie Draper" });
            var decommissionedShip = new DecommissionedShip { Name = "Canterbury", Date = new DateTime (2350, 1, 1) };
            var context = new ExpanseContext ();
            context.Ships.InsertMany (new [] { ship, decommissionedShip });
        }

        private static void ApplyMappings () {
            BsonClassMap.RegisterClassMap<Ship> (cm => {
                cm.AutoMap ();
                cm.SetDiscriminatorIsRequired (true);
            });
            BsonClassMap.RegisterClassMap<DecommissionedShip> (cm => {
                cm.AutoMap ();
                cm.SetDiscriminatorIsRequired (true);
            });
            BsonClassMap.RegisterClassMap<Character> (cm => {
                cm.AutoMap ();
                cm.SetDiscriminatorIsRequired (true);
            });
        }

        private static void GetDataViaAPI () {
            var context = new ExpanseContext ();
            var filter = new BsonDocument ();
            var docs = context.BsonDocs.Find (filter)
                .Project (Builders<BsonDocument>.Projection.Exclude ("_id")).ToList ();

            var docs2 = context.Ships.AsQueryable ().ToList ();
        }
    }
}