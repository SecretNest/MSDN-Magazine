using System;
using System.Collections.Generic;
using MongoDB.Bson.Serialization.Attributes;

namespace MongoTest
{

  public class Ship {
        public Ship () {
            Crew = new List<Character> ();
        }
        public string Name { get; set; }
        public Guid Id { get; set; }
        public List<Character> Crew { get; set; }
    }
}