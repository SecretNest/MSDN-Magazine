using MongoDB.Bson;
using MongoDB.Driver;
using MongoTest;

public class ExpanseContext {
    public IMongoDatabase ExpanseDb { get; private set; }
    public IMongoCollection<Ship> Ships { get; private set; }
    public IMongoCollection<Character> Characters { get; private set; }
    public IMongoCollection<BsonDocument> BsonDocs { get; private set; }
    public ExpanseContext () {
       ///pointto non-default e.g. azure:
       // var connString="mongodb://....==@datapointsmongodbs.documents.azure.com:10255/?ssl=true";
       // ExpanseDb=new MongoClient(connString).GetDatabase("ExpanseDatabase");
       ///point to default 127.0.0.1:27017
        ExpanseDb = new MongoClient ().GetDatabase ("ExpanseDatabase");
        Ships = ExpanseDb.GetCollection<Ship> ("Ships");
        Characters = ExpanseDb.GetCollection<Character> ("Ships");
        BsonDocs = ExpanseDb.GetCollection<BsonDocument> ("Ships");

    }

}