using System;

namespace MongoTest
{
  public class DecommissionedShip  : Ship {
        public DateTime Date { get; set; }
    }
}