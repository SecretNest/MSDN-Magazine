﻿using System;
using System.Collections.Generic;
using System.IO;
namespace SOmap
{
  class SOmapProgram
  {
    static void Main(string[] args)
    {
      Console.WriteLine("\nBegin self-organizing map demo \n");
      Random rnd = new Random(0);
      int Rows = 5, Cols = 5;  // map dims
      int RangeMax = Rows + Cols;  // Manhattan distance neighbor range
      double LearnRateMax = 0.5;
      int StepsMax = 100000;  // max iteration 'steps'
      // int StepsMax = 1000;

      // initialize SOM nodes to random values
      double[][][] map = new double[Rows][][];  // [r][c][vec]
      for (int i = 0; i < Rows; ++i) {
        map[i] = new double[Cols][];
        for (int j = 0; j < Cols; ++j) {
          map[i][j] = new double[64];
          for (int k = 0; k < 64; ++k)
            map[i][j][k] = rnd.NextDouble();
        }
      }

      // read data and labels into memory
      Console.WriteLine("Reading UCI digits data into memory");
      double[][] data = new double[1797][];
      for (int i = 0; i < 1797; ++i)
        data[i] = new double[64];

      int[] labels = new int[1797];

      FileStream ifs = new FileStream("..\\..\\digits_uci.txt",
        FileMode.Open);
      StreamReader sr = new StreamReader(ifs);
      string line = ""; string[] tokens = null;
      int row = 0;
      while ((line = sr.ReadLine()) != null)  {
        tokens = line.Split(',');
        for (int j = 0; j < 64; ++j)
          data[row][j] = double.Parse(tokens[j]) / 16.0;
        labels[row] = int.Parse(tokens[64]);
        ++row;
      }
      sr.Close(); ifs.Close();

      // construct the SOM
      Console.WriteLine("Constructing 5x5 SO Map");
      for (int s = 0; s < StepsMax; ++s)  // main iteration loop
      {
        if (s % (int)(StepsMax/5) == 0 && s > 0)
          Console.WriteLine("step = " + s);

        double pctLeft = 1.0 - ((s * 1.0) / StepsMax);  // pct steps left
        int currRange = (int)(pctLeft * RangeMax);  // max dist to a 'neighbor'
        double currLearnRate = pctLeft * LearnRateMax;

        // pick random data index
        int t = rnd.Next(0, 1797);
        // get (row,col) of closest map node -- 'bmu'
        int[] bmuRC = ClosestNode(data, t, map);
        // move each map mode closer to the bmu
        for (int i = 0; i < Rows; ++i) {
          for (int j = 0; j < Cols; ++j) {
            if (ManDist(bmuRC[0], bmuRC[1], i, j) <= currRange)  // in range
              for (int k = 0; k < 64; ++k)
                map[i][j][k] = map[i][j][k] +
                  currLearnRate * (data[t][k] - map[i][j][k]);
          } // j
        } // i
      } // s(tep)
      Console.WriteLine("Map construction complete \n");

      // show one map node
      Console.WriteLine("Value of map[1][1] vector is: ");
      Console.WriteLine(map[1][1][0].ToString("F4") + "  " +
        map[1][1][1].ToString("F4") + " . . " + map[1][1][63].ToString("F4"));
      Console.WriteLine(" [0]     [1]   . .  [63] \n");

      //// map created. make a U-Matrix
      //double[][] uMatrix = new double[Rows][];
      //for (int i = 0; i < Rows; ++i)
      //  uMatrix[i] = new double[Cols];

      //for (int i = 0; i < Rows; ++i)
      //{
      //  for (int j = 0; j < Cols; ++j)
      //  {
      //    double sumDists = 0.0;
      //    int ct = 0;
      //    double[] v = map[i][j];
      //    if (i - 1 >= 0) { sumDists += EucDist(map[i - 1][j], v); ++ct; }
      //    if (i + 1 <= Rows -1) { sumDists += EucDist(map[i + 1][j], v); ++ct; }
      //    if (j - 1 >= 0) { sumDists += EucDist(map[i][j-1], v); ++ct; }
      //    if (j + 1 <= Cols - 1) { sumDists += EucDist(map[i][j+1], v); ++ct; }
      //    uMatrix[i][j] = sumDists / ct;
      //    uMatrix[i][j] /= 64;  // normalize to vector length
      //  }
      //}

      //// display U-Matrix
      //for (int i = 0; i < Rows; ++i)
      //{
      //  for (int j = 0; j < Cols; ++j)
      //  {
      //    Console.Write(uMatrix[i][j].ToString("F4") + " ");
      //  }
      //  Console.WriteLine("");
      //}
      //Console.WriteLine("\n");

      // map has been created. assign data items to map
      Console.WriteLine("Assigning data indices to map \n");
      List<int>[][] mapping = new List<int>[Rows][];  // list of data indices
      for (int i = 0; i < Rows; ++i)
        mapping[i] = new List<int>[Cols];
      for (int i = 0; i < Rows; ++i)
        for (int j = 0; j < Cols; ++j)
          mapping[i][j] = new List<int>();

      for (int t = 0; t < 1797; ++t)  // each data item
      {
        // find node map coords where node vec is closest to D(t)
        int[] rc = ClosestNode(data, t, map);
        int r = rc[0]; int c = rc[1];
        mapping[r][c].Add(t);
      }

      Console.WriteLine("Data indices assigned to map[3][3]: ");
      foreach (int idx in mapping[3][3])
        Console.Write(idx.ToString().PadLeft(5) + "  ");
      Console.WriteLine("\n");

      for (int i = 0; i < Rows; ++i)
      {
        for (int j = 0; j < Cols; ++j)
        {
          List<int> members = new List<int>();  // '0' - '9' labels
          Console.WriteLine("================");
          Console.Write("cell = ");
          Console.WriteLine(i.ToString() + " " + j.ToString());
          Console.WriteLine("labels assigned to cell:");
          foreach (int idx in mapping[i][j])
          {
            int lbl = labels[idx];
            members.Add(lbl);
            Console.Write(lbl + " ");
          }
          int mcv = MostCommonVal(members);
          Console.Write("\nmost common label in cell = ");
          Console.WriteLine(mcv);
          //Console.WriteLine("");
          Console.WriteLine("================");
        }
      }

      
      // show one possible visualization
      Console.WriteLine("Most common labels for each map node: ");
      for (int i = 0; i < Rows; ++i) {
        for (int j = 0; j < Cols; ++j) {
          List<int> members = new List<int>();  // '0' - '9' labels
          foreach (int idx in mapping[i][j])
            members.Add(labels[idx]);
          int mcv = MostCommonVal(members);
          Console.Write(mcv + "  ");
        }
        Console.WriteLine("");
      }

      Console.WriteLine("\nEnd self-organizing map demo");
      Console.ReadLine();
    } // Main

    static int ManDist(int x1, int y1, int x2, int y2)
    {
      return Math.Abs(x1 - x2) + Math.Abs(y1 - y2);
    }

    static double EucDist(double[] v1, double[] v2)
    {
      double sum = 0;
      for (int i = 0; i < v1.Length; ++i)
        sum += (v1[i] - v2[i]) * (v1[i] - v2[i]);
      return Math.Sqrt(sum);
    }

    static int[] ClosestNode(double[][] data, int t, double[][][] map)
    {
      // coords in map of node closest to data[t]
      double smallDist = double.MaxValue;
      int[] result = new int[] { 0, 0 };  // (row, col)
      for (int i = 0; i < map.Length; ++i) {
        for (int j = 0; j < map[0].Length; ++j)  {
          double dist = EucDist(data[t], map[i][j]);
          if (dist < smallDist) {
            smallDist = dist; result[0] = i; result[1] = j;
          }
        }
      }
      return result;
    }

    static int MostCommonVal(List<int> list)
    {
      if (list.Count == 0) return -1;
      int largestCount = 0; int mostCommon = 0;
      int[] counts = new int[10];
      foreach (int val in list) {
        ++counts[val];
        if (counts[val] > largestCount) {
          largestCount = counts[val]; mostCommon = val;
        }
      }
      return mostCommon;
    }

  } // Program
} // ns
