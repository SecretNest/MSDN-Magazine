﻿using System.Collections.Generic;
using Microsoft.Quantum.Simulation.Core;

namespace SuperdenseCoding
{
	public class AliceQubitMessage
	{
		public IEnumerable<Qubit> Qubits { get; }

		public AliceQubitMessage(IEnumerable<Qubit> qubits)
		{
			Qubits = qubits;
		}
	}
}