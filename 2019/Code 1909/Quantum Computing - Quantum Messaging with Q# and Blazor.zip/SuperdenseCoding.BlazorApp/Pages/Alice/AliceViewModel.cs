﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Codon;
using Codon.Messaging;
using Codon.UIModel;
using Codon.UIModel.Input;
using Microsoft.Quantum.Simulation.Core;

namespace SuperdenseCoding.Views
{
	public class AliceViewModel : ViewModelBase, 
		IMessageSubscriber<AliceQubitMessage>
	{
		readonly Queue<Qubit> qubitQueue = new Queue<Qubit>();
		readonly Queue<byte> byteQueue = new Queue<byte>();
		const int qubitsRequiredForByte = 4;

		async Task IMessageSubscriber<AliceQubitMessage>.ReceiveMessageAsync(
			AliceQubitMessage message)
		{
			foreach (var qubit in message.Qubits)
			{
				qubitQueue.Enqueue(qubit);
			}

			await DispatchItemsInQueue();
		}

		async Task DispatchItemsInQueue()
		{
			var qOps = Dependency.Resolve<QOperations, QOperations>(true);

			while (byteQueue.Any())
			{
				if (qubitQueue.Count < qubitsRequiredForByte)
				{
					return;
				}

				IList<Qubit> qubits = qubitQueue.DequeueMany(qubitsRequiredForByte).ToList();

				byte b = byteQueue.Dequeue();
				BitArray bitArray = new BitArray(new[] { b });
				
				/* Convert classical bit pairs to single qubits. */
				for (int i = 0, j = 0; i < bitArray.Length; i += 2, j++)
				{
					await qOps.EncodeMessageInQubitAsync(
						qubits[j], 
						bitArray[i], 
						bitArray[i + 1]);
				}

				await Messenger.PublishAsync(new DecodeQubitsMessage(qubits));
			}
		}

		public int QubitCount => qubitQueue.Count;

		string message;

		public string Message
		{
			get => message;
			set => Set(ref message, value);
		}

		ICommand sendCommand;

		public ICommand SendCommand => sendCommand
				?? (sendCommand = new AsyncActionCommand(SendAsync));

		async Task SendAsync(object arg)
		{
			var bytes = Encoding.ASCII.GetBytes(Message);

			foreach (byte b in bytes)
			{
				byteQueue.Enqueue(b);
				await Messenger.PublishAsync(
							new RequestQubitsMessage(qubitsRequiredForByte));
			}

			Message = string.Empty;
		}
	}
}