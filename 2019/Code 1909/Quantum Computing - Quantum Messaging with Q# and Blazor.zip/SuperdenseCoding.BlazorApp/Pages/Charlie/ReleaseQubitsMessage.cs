﻿using System.Collections.Generic;
using Microsoft.Quantum.Simulation.Core;

namespace SuperdenseCoding
{
	public class ReleaseQubitsMessage
	{
		public IEnumerable<Qubit> Qubits { get; }

		public ReleaseQubitsMessage(IEnumerable<Qubit> qubits)
		{
			Qubits = qubits;
		}
	}
}