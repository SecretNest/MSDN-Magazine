﻿namespace SuperdenseCoding
{
	public class RequestQubitsMessage
	{
		public int QubitCount { get; }

		public RequestQubitsMessage(int qubitCount)
		{
			QubitCount = qubitCount;
		}
	}
}