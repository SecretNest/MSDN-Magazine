﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using Codon;
using Codon.Messaging;
using Codon.UIModel;
using Microsoft.Quantum.Simulation.Core;

namespace SuperdenseCoding.Views
{
	public class CharlieViewModel : ViewModelBase, 
		IMessageSubscriber<RequestQubitsMessage>, 
		IMessageSubscriber<ReleaseQubitsMessage>
	{
		QOperations qOps_UseProperty;
		
		QOperations QOperations => qOps_UseProperty ?? 
			(qOps_UseProperty = Dependency.Resolve<QOperations, QOperations>(true));

		async Task IMessageSubscriber<RequestQubitsMessage>.ReceiveMessageAsync(RequestQubitsMessage message)
		{
			IList<(Qubit, Qubit)> qubits = await QOperations.GetEntangledPairsAsync(message.QubitCount);

			await Messenger.PublishAsync(new BobQubitMessage(qubits.Select(x => x.Item2)));
			await Messenger.PublishAsync(new AliceQubitMessage(qubits.Select(x => x.Item1)));

			QubitSentCount += message.QubitCount;
		}

		async Task IMessageSubscriber<ReleaseQubitsMessage>.ReceiveMessageAsync(ReleaseQubitsMessage message)
		{
			await QOperations.ReleaseQubitsAsync(message.Qubits);
		}

		readonly ObservableCollection<MessageItem> messages = new ObservableCollection<MessageItem>();

		public IEnumerable<MessageItem> Messages => messages;

		void AddMessage(string message)
		{
			PropertyChangeNotifier.SynchronizationContext.Post(
				() => {messages.Add(new MessageItem(message));});
		}

		int qubitSentCount;

		public int QubitSentCount
		{
			get => qubitSentCount;
			set => Set(ref qubitSentCount, value);
		}
	}
}