﻿using System.Collections.Generic;
using Microsoft.Quantum.Simulation.Core;

namespace SuperdenseCoding.Views
{
	public class DecodeQubitsMessage
	{
		public IList<Qubit> Qubits { get; }

		public DecodeQubitsMessage(IList<Qubit> qubits)
		{
			Qubits = qubits;
		}
	}
}