﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Codon;
using Codon.Messaging;
using Codon.UIModel;
using Microsoft.Quantum.Simulation.Core;

namespace SuperdenseCoding.Views
{
	public class BobViewModel : ViewModelBase, 
		IMessageSubscriber<BobQubitMessage>, 
		IMessageSubscriber<DecodeQubitsMessage>
	{
		readonly Queue<Qubit> qubits = new Queue<Qubit>();
		
		Task IMessageSubscriber<BobQubitMessage>.ReceiveMessageAsync(BobQubitMessage message)
		{
			foreach (var qubit in message.Qubits)
			{
				qubits.Enqueue(qubit);
			}

			return Task.CompletedTask;
		}
		
		async Task IMessageSubscriber<DecodeQubitsMessage>.ReceiveMessageAsync(DecodeQubitsMessage message)
		{
			IList<Qubit> aliceQubits = message.Qubits;
			List<Qubit> bobQubits = qubits.DequeueMany(aliceQubits.Count).ToList();

			var qOps = Dependency.Resolve<QOperations, QOperations>(true);
			var bytes = new List<byte>();

			for (int i = 0; i < bobQubits.Count; i += 4)
			{
				byte b = 0;
				for (int j = 0; j < 4; j++)
				{
					(bool aliceBit, bool bobBit) = await qOps.DecodeQubits(bobQubits[i + j], aliceQubits[i + j]);

					if (bobBit)
					{
						b |= (byte)(1 << (j * 2 + 1));
					}

					if (aliceBit)
					{
						b |= (byte)(1 << (j * 2));
					}
				}
				bytes.Add(b);
			}

			await Messenger.PublishAsync(new ReleaseQubitsMessage(aliceQubits));
			await Messenger.PublishAsync(new ReleaseQubitsMessage(bobQubits));

			Message += Encoding.ASCII.GetString(bytes.ToArray());
		}

		string message;
		
		public string Message
		{
			get => message;
			set => Set(ref message, value);
		}

		// readonly ObservableCollection<MessageItem> messages = new ObservableCollection<MessageItem>();
		//
		// public IEnumerable<MessageItem> Messages => messages;
		//
		// void AddMessage(string message)
		// {
		// 	PropertyChangeNotifier.SynchronizationContext.Post(
		// 		() => { messages.Add(new MessageItem(message)); });
		// }
	}

	public class MessageItem
	{
		public string Message { get; }

		public DateTime TimeStamp { get; } = DateTime.Now;

		public MessageItem(string message)
		{
			Message = message;
		}
	}
}