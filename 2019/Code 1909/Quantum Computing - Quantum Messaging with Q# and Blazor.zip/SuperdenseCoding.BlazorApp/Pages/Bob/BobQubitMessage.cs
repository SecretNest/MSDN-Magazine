﻿using System.Collections.Generic;
using Microsoft.Quantum.Simulation.Core;

namespace SuperdenseCoding
{
	public class BobQubitMessage
	{
		public IEnumerable<Qubit> Qubits { get; }

		public BobQubitMessage(IEnumerable<Qubit> qubits)
		{
			Qubits = qubits;
		}
	}
}