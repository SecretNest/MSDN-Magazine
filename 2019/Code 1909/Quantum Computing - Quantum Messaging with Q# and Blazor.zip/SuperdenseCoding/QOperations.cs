﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Quantum.Intrinsic;
using Microsoft.Quantum.Simulation.Core;
using Microsoft.Quantum.Simulation.Simulators;

namespace SuperdenseCoding
{
	public class QOperations
	{
		readonly QuantumSimulator simulator = new QuantumSimulator();
		readonly ICallable<Qubit, QVoid> resetOperation;
		readonly Release releaseOperation;
		readonly IUnitary<Qubit> hGate;
		readonly IUnitary<(Qubit, Qubit)> cnotGate;
		readonly Allocate allocator;

		public QOperations()
		{
			resetOperation = simulator.Get<ICallable<Qubit, QVoid>>(typeof(Reset));
			releaseOperation = simulator.Get<Release>(typeof(Release));
			allocator = simulator.Get<Allocate>(typeof(Allocate));
			cnotGate = simulator.Get<IUnitary<(Qubit, Qubit)>>(typeof(CNOT));
			hGate = simulator.Get<IUnitary<Qubit>>(typeof(H));
		}

		/// <summary>
		/// Creates a list of qubit tuples. The qubits in each tuple
		/// are entangled with each other. One is to be sent to Alice,
		/// and one to Bob.
		/// </summary>
		/// <param name="count">The number of qubit tuples to prepare.</param>
		public Task<IList<(Qubit, Qubit)>> GetEntangledPairsAsync(int count)
		{
			IList<(Qubit, Qubit)> result = new List<(Qubit, Qubit)>(count);

			for (int i = 0; i < count; i++)
			{
				var qubits = allocator.Apply(2);
				hGate.Apply(qubits[0]);
				cnotGate.Apply((qubits[0], qubits[1]));
				result.Add((qubits[0], qubits[1]));

				/* Initially reset and release was performed in the generated file. */
				//var qubits = await QubitGenerator.Run(simulator);
			}

			return Task.FromResult(result);
		}

		/// <summary>
		/// Frees the specified qubits, which reduces resources.
		/// This method must be called to prevent the simulator
		/// from using too much memory.
		/// </summary>
		/// <param name="qubits">The qubits that are not longer being used.</param>
		public Task ReleaseQubitsAsync(IEnumerable<Qubit> qubits)
		{
			foreach (Qubit qubit in qubits)
			{
				resetOperation.Apply(qubit);
				releaseOperation.Apply(qubit);
				/* Alternatively we could do: */
				//simulator.QubitManager.Release(qubit);
			}

			return Task.CompletedTask;
		}

		/// <summary>
		/// Encode the message (classical bits) in the state of Alice's qubit.
		/// </summary>
		/// <param name="aliceQubit">Alice's part of the entangled pair of qubits.</param>
		/// <param name="bit1">The first bit of information to encode.</param>
		/// <param name="bit2">The second bit of information to encode.</param>
		public async Task EncodeMessageInQubitAsync(Qubit aliceQubit, bool bit1, bool bit2)
		{
			await EncodeMessageInQubit.Run(
					simulator, aliceQubit, bit1, bit2);
		}

		/// <summary>
		/// Retrieves two classical bits from the qubits.
		/// </summary>
		/// <param name="bobQubit">Bob's part of the entangled pair.</param>
		/// <param name="aliceQubit">Qubit received from Alice.</param>
		/// <returns>A tuple containing two classical bits.</returns>
		public async Task<(bool Alice, bool Bob)> DecodeQubits(Qubit bobQubit, Qubit aliceQubit)
		{
			(bool, bool) bits = await DecodeMessageFromQubits.Run(simulator, bobQubit, aliceQubit);
			return bits;
		}
	}
}
