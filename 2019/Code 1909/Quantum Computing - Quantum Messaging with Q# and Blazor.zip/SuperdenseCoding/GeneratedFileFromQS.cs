﻿// using System;
// using System.Collections.Generic;
// using Microsoft.Quantum.Intrinsic;
// using Microsoft.Quantum.Simulation.Core;
//
// namespace SuperdenseCoding
// {
// 	class QubitGenerator : Operation<QVoid, (Qubit, Qubit)>, ICallable
// 	{
// 		public QubitGenerator(IOperationFactory m) : base(m)
// 		{
// 		}
//
// 		public class Out : QTuple<(Qubit, Qubit)>, IApplyData
// 		{
// 			public Out((Qubit, Qubit) data) : base(data)
// 			{
// 			}
//
// 			System.Collections.Generic.IEnumerable<Qubit> IApplyData.Qubits
// 			{
// 				get
// 				{
// 					yield return Data.Item1;
// 					yield return Data.Item2;
// 				}
// 			}
// 		}
//
// 		String ICallable.Name => "QubitGenerator";
// 		String ICallable.FullName => "SuperdenseCoding.QubitGenerator";
// 		protected Allocate Allocate
// 		{
// 			get;
// 			set;
// 		}
//
// 		protected IUnitary<(Qubit, Qubit)> MicrosoftQuantumIntrinsicCNOT
// 		{
// 			get;
// 			set;
// 		}
//
// 		protected IUnitary<Qubit> MicrosoftQuantumIntrinsicH
// 		{
// 			get;
// 			set;
// 		}
//
// 		protected ICallable<String, QVoid> MicrosoftQuantumIntrinsicMessage
// 		{
// 			get;
// 			set;
// 		}
//
// 		protected Release Release
// 		{
// 			get;
// 			set;
// 		}
//
// 		protected ICallable<IQArray<Qubit>, QVoid> MicrosoftQuantumIntrinsicResetAll
// 		{
// 			get;
// 			set;
// 		}
//
// 		protected ICallable<Qubit, QVoid> MicrosoftQuantumIntrinsicReset
// 		{
// 			get;
// 			set;
// 		}
//
// 		public override Func<QVoid, (Qubit, Qubit)> Body => (__in__) =>
// 		{
// 			MicrosoftQuantumIntrinsicMessage.Apply("Creating two qubits.");
// 			var qs = Allocate.Apply(2L);
// 			Exception exception = null;
// 			try
// 			{
// 				MicrosoftQuantumIntrinsicH.Apply(qs[0L]);
// 				MicrosoftQuantumIntrinsicCNOT.Apply((qs[0L], qs[1L]));
// 				return (qs[0L], qs[1L]);
// 			}
// 			catch (Exception ex)
// 			{
// 				exception = ex;
// 				throw exception;
// 			}
// 			finally
// 			{
// 				if (exception != null)
// 				{
// 					throw exception;
// 				}
// 			}
// 		};
//
// 		public override void Init()
// 		{
// 			this.Allocate = this.Factory.Get<Allocate>(typeof(Microsoft.Quantum.Intrinsic.Allocate));
// 			this.MicrosoftQuantumIntrinsicCNOT = this.Factory.Get<IUnitary<(Qubit, Qubit)>>(typeof(Microsoft.Quantum.Intrinsic.CNOT));
// 			this.MicrosoftQuantumIntrinsicH = this.Factory.Get<IUnitary<Qubit>>(typeof(Microsoft.Quantum.Intrinsic.H));
// 			this.MicrosoftQuantumIntrinsicMessage = this.Factory.Get<ICallable<String, QVoid>>(typeof(Microsoft.Quantum.Intrinsic.Message));
// 			this.Release = this.Factory.Get<Release>(typeof(Microsoft.Quantum.Intrinsic.Release));
// 			this.MicrosoftQuantumIntrinsicResetAll = this.Factory.Get<ICallable<IQArray<Qubit>, QVoid>>(typeof(Microsoft.Quantum.Intrinsic.ResetAll));
// 			this.MicrosoftQuantumIntrinsicReset = this.Factory.Get<ICallable<Qubit, QVoid>>(typeof(Microsoft.Quantum.Intrinsic.Reset));
// 		}
//
// 		public override IApplyData __dataIn(QVoid data) => data;
// 		public override IApplyData __dataOut((Qubit, Qubit) data) => new QubitGenerator.Out(data);
// 		public static System.Threading.Tasks.Task<(Qubit, Qubit)> Run(IOperationFactory __m__)
// 		{
// 			return __m__.Run<QubitGenerator, QVoid, (Qubit, Qubit)>(QVoid.Instance);
// 		}
//
// 		public void ReleaseQubits(IEnumerable<Qubit> qubits)
// 		{
// 			foreach (Qubit qubit in qubits)
// 			{
// 				MicrosoftQuantumIntrinsicReset.Apply(qubit);
// 				Release.Apply(qubit);
// 			}
// 		}
// 	}
// }