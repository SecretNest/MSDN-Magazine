﻿using Codon.Concurrency;
using Codon.UIModel;

namespace SuperdenseCoding
{
	public abstract class CustomViewModel : ViewModelBase
	{
		protected CustomViewModel()
		{
			var context = new UISynchronizationContext();
			context.Initialize();
			SynchronizationContext = context;
			PropertyChangeNotifier.SynchronizationContext = context;
		}

		protected ISynchronizationContext SynchronizationContext { get; }
	}
}
