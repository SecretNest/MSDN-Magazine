﻿using Windows.UI.Xaml.Controls;

namespace SuperdenseCoding.Views
{
	public sealed partial class CharlieView : Page
	{
		public CharlieView()
		{
			DataContext = new CharlieViewModel();

			this.InitializeComponent();
		}

		public CharlieViewModel ViewModel => (CharlieViewModel)this.DataContext;

		
	}
}
