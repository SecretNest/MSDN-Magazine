﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Codon;
using Codon.Messaging;
using Codon.UIModel.Input;
using Microsoft.Quantum.Simulation.Core;

namespace SuperdenseCoding.Views
{
	public class AliceViewModel : CustomViewModel, IMessageSubscriber<AliceQubitMessage>
	{
		readonly Queue<Qubit> qubits = new Queue<Qubit>();
		readonly Queue<byte> queue = new Queue<byte>();
		const int qubitsRequiredForByte = 4;

		async Task IMessageSubscriber<AliceQubitMessage>.ReceiveMessageAsync(AliceQubitMessage message)
		{
			foreach (var qubit in message.Qubits)
			{
				qubits.Enqueue(qubit);
			}

			await DispatchItemsInQueue();
		}

		async Task DispatchItemsInQueue()
		{
			while (queue.Any())
			{
				if (qubits.Count < qubitsRequiredForByte)
				{
					return;
				}

				var byteBits = qubits.DequeueMany(qubitsRequiredForByte).ToList();

				byte b = queue.Dequeue();
				BitArray bitArray = new BitArray(new[] { b });

				var qOps = Dependency.Resolve<QOperations, QOperations>(true);
				/* Convert classical bit pairs to single qubits. */
				for (int i = 0, j = 0; i < bitArray.Length; i += 2, j++)
				{
					await qOps.EncodeQubitForMessage(
						byteBits[j], 
						bitArray[i], 
						bitArray[i + 1]);
				}

				await Messenger.PublishAsync(new DecodeQubitsMessage(byteBits));
			}
		}

		public int QubitCount => qubits.Count;

		string message;

		public string Message
		{
			get => message;
			set => Set(ref message, value);
		}

		ICommand sendCommand;

		public ICommand SendCommand => sendCommand
				?? (sendCommand = new AsyncActionCommand(Send));

		async Task Send(object arg)
		{
			var bytes = Encoding.ASCII.GetBytes(Message);

			foreach (byte b in bytes)
			{
				queue.Enqueue(b);
				await Messenger.PublishAsync(
							new RequestQubitsMessage(qubitsRequiredForByte));
			}

			Message = string.Empty;
		}
	}


	public static class QueueExtensions
	{
		public static IEnumerable<T> DequeueMany<T>(this Queue<T> queue, int count)
		{
			for (int i = 0; i < count && queue.Count > 0; i++)
			{
				yield return queue.Dequeue();
			}
		}
	}
}