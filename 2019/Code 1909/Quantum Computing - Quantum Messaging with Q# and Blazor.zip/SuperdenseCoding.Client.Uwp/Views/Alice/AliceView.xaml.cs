﻿using Windows.UI.Xaml.Controls;

namespace SuperdenseCoding.Views
{
	public sealed partial class AliceView : Page
	{
		public AliceView()
		{
			DataContext = new AliceViewModel();

			this.InitializeComponent();
		}

		public AliceViewModel ViewModel => (AliceViewModel)this.DataContext;
	}
}