﻿using Windows.UI.Xaml.Controls;

namespace SuperdenseCoding.Views
{
	public sealed partial class BobView : Page
	{
		public BobView()
		{
			DataContext = new BobViewModel();

			this.InitializeComponent();
		}

		public BobViewModel ViewModel => (BobViewModel)this.DataContext;
	}
}