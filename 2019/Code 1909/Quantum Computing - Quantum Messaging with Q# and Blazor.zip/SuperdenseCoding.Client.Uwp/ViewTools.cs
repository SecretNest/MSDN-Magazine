﻿using System;
using System.Threading.Tasks;
using Windows.ApplicationModel.Core;
using Windows.UI.Core;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace SuperdenseCoding
{
	class ViewTools
	{
		static int lastViewId;

		public static async Task<int> OpenView(Type viewType, int parentViewId, string title)
		{
			if (lastViewId == 0)
			{
				lastViewId = ApplicationView.GetForCurrentView().Id;
			}

			if (parentViewId == 0)
			{
				parentViewId = lastViewId;
			}

			ApplicationView.PreferredLaunchViewSize = new Windows.Foundation.Size(200, 200);
			ApplicationView.PreferredLaunchWindowingMode = ApplicationViewWindowingMode.PreferredLaunchViewSize;

			CoreApplicationView newView = CoreApplication.CreateNewView();
			int newViewId = 0;
			await newView.Dispatcher.RunAsync(CoreDispatcherPriority.Normal, () =>
			{
				Frame frame = new Frame();
				frame.Navigate(viewType, null);
				Window.Current.Content = frame;
				// You have to activate the window in order to show it later.
				Window.Current.Activate();
				var view = ApplicationView.GetForCurrentView();
				newViewId = view.Id;
				view.Title = title;
			});
			bool viewShown = await ApplicationViewSwitcher.TryShowAsStandaloneAsync(
						newViewId, ViewSizePreference.Custom, lastViewId, ViewSizePreference.Default);
			lastViewId = newViewId;
			return newViewId;
		}
	}
}
