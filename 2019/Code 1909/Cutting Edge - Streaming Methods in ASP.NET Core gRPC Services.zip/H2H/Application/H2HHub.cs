﻿using Microsoft.AspNetCore.SignalR;

namespace H2H.Application
{
    public class H2HHub : Hub
    {
        
    }
}