namespace H2H.Models
{
    public class H2HViewModel
    {
        public string Player1 { get; set; }
        public uint Won1 { get; set; }

        public string Player2 { get; set; }
        public uint Won2 { get; set; }

    }
}