In Visual Studio:
- Modify the values of the Uri attributes in the .appinstaller file
- Push the solution to a source code repository
In a Web Browser:
- Browse to the Azure DevOps portal and set up a build pipeline based on the YAML file
- Upload the certificate.pfx file as a secure file
- Define a secret variable called "password" with a value of "secret"
- Queue and run a build
- Download the build artifacts to the client machine or set up a release pipeline with a command-line task that copies the artifacts to the file share specified in the .appinstaller file.
On the client machine:
- Import the certificate
- Double-click on the .appinstaller or .msix file to install the packaged application