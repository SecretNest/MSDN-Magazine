﻿namespace DataAPIDocker

{
    public class Magazine
    {
        public int MagazineId { get; set; }
        public string Name { get; set; }
    }
}