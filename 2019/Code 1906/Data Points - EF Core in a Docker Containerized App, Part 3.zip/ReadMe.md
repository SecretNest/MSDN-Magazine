EF Core in a Docker Containerized App Part 3

June 2019 MSDN Magazine


https://msdn.microsoft.com/en-us/magazine/mt149362?author=julie+lerman

Note that in the article, I discussed using volumes for persistent data. This is not a great practice when testing and debugging the demo app I created. The reason is that if you want to start over, removing the containers, the data volume does not get removed. So you won't get to start from scratch. I discovered this the hard way when I decided to change the environment variable for the password. In my real files, I had a password that followed the requirements for the SQL Server container with a tiny bit of complexity. But in the article I shortened it to "eiluj" which won't work. (I'm so sorry and now it's too late to fix the article.) When I went to change the environent variable password, the new password was never being used but always the old one which existed nowhere in my code. Finally I deleted the volume and the new password got used to create a new volume.

This folder contains the .NET Core API solution described in the article.

Julie Lerman

thedatafarm.com

twitter @julielerman